//////////////////////////////////////////////////////////////////////////////////
// nvme_io_cmd.c for Cosmos+ OpenSSD
// Copyright (c) 2016 Hanyang University ENC Lab.
// Contributed by Yong Ho Song <yhsong@enc.hanyang.ac.kr>
//				  Youngjin Jo <yjjo@enc.hanyang.ac.kr>
//				  Sangjin Lee <sjlee@enc.hanyang.ac.kr>
//				  Jaewook Kwak <jwkwak@enc.hanyang.ac.kr>
//
// This file is part of Cosmos+ OpenSSD.
//
// Cosmos+ OpenSSD is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 3, or (at your option)
// any later version.
//
// Cosmos+ OpenSSD is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Cosmos+ OpenSSD; see the file COPYING.
// If not, see <http://www.gnu.org/licenses/>.
//////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////
// Company: ENC Lab. <http://enc.hanyang.ac.kr>
// Engineer: Sangjin Lee <sjlee@enc.hanyang.ac.kr>
//			 Jaewook Kwak <jwkwak@enc.hanyang.ac.kr>
//
// Project Name: Cosmos+ OpenSSD
// Design Name: Cosmos+ Firmware
// Module Name: NVMe IO Command Handler
// File Name: nvme_io_cmd.c
//
// Version: v1.0.1
//
// Description:
//   - handles NVMe IO command
//////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////
// Revision History:
//
// * v1.0.1
//   - header file for buffer is changed from "ia_lru_buffer.h" to "lru_buffer.h"
//
// * v1.0.0
//   - First draft
//////////////////////////////////////////////////////////////////////////////////


#include "xil_printf.h"
#include "debug.h"
#include "io_access.h"

#include "nvme.h"
#include "host_lld.h"
#include "nvme_io_cmd.h"

#include "../ftl_config.h"
#include "../kv_store.h"
#include "../request_transform.h"

// NVME pass through need is in this code.
void handle_nvme_io_read(unsigned int cmdSlotTag, NVME_IO_COMMAND *nvmeIOCmd)
{
	IO_READ_COMMAND_DW12 readInfo12;
	//IO_READ_COMMAND_DW13 readInfo13;
	//IO_READ_COMMAND_DW15 readInfo15;
	unsigned int startLba[2];
	unsigned int nlb;
	unsigned int nsid = nvmeIOCmd->NSID;
	

	readInfo12.dword = nvmeIOCmd->dword[12];
	//readInfo13.dword = nvmeIOCmd->dword[13];
	//readInfo15.dword = nvmeIOCmd->dword[15];

	startLba[0] = nvmeIOCmd->dword[10];
	startLba[1] = nvmeIOCmd->dword[11];
	nlb = readInfo12.NLB;

	ASSERT(startLba[0] < storageCapacity_L / USER_CHANNELS && (startLba[1] < STORAGE_CAPACITY_H || startLba[1] == 0));
	//ASSERT(nlb < MAX_NUM_OF_NLB);
	ASSERT((nvmeIOCmd->PRP1[0] & 0x3) == 0 && (nvmeIOCmd->PRP2[0] & 0x3) == 0); //error
	ASSERT(nvmeIOCmd->PRP1[1] < 0x10000 && nvmeIOCmd->PRP2[1] < 0x10000);

	ReqTransNvmeToSlice(cmdSlotTag, startLba[0] + (storageCapacity_L / USER_CHANNELS) * (nsid - 1), nlb, IO_NVM_READ);
}


void handle_nvme_io_write(unsigned int cmdSlotTag, NVME_IO_COMMAND *nvmeIOCmd)
{
	IO_READ_COMMAND_DW12 writeInfo12;
	//IO_READ_COMMAND_DW13 writeInfo13;
	//IO_READ_COMMAND_DW15 writeInfo15;
	unsigned int startLba[2];
	unsigned int nlb;
	unsigned int nsid = nvmeIOCmd->NSID;

	writeInfo12.dword = nvmeIOCmd->dword[12];
	//writeInfo13.dword = nvmeIOCmd->dword[13];
	//writeInfo15.dword = nvmeIOCmd->dword[15];

	//if(writeInfo12.FUA == 1)
	//	xil_printf("write FUA\r\n");

	startLba[0] = nvmeIOCmd->dword[10];
	startLba[1] = nvmeIOCmd->dword[11];
	nlb = writeInfo12.NLB;

	ASSERT(startLba[0] < storageCapacity_L / USER_CHANNELS && (startLba[1] < STORAGE_CAPACITY_H || startLba[1] == 0));
	//ASSERT(nlb < MAX_NUM_OF_NLB);
	ASSERT((nvmeIOCmd->PRP1[0] & 0xF) == 0 && (nvmeIOCmd->PRP2[0] & 0xF) == 0);
	ASSERT(nvmeIOCmd->PRP1[1] < 0x10000 && nvmeIOCmd->PRP2[1] < 0x10000);

	ReqTransNvmeToSlice(cmdSlotTag, startLba[0] + (storageCapacity_L / USER_CHANNELS) * (nsid - 1), nlb, IO_NVM_WRITE);
}

void handle_nvme_io_hello()
{
	/*Name: Gildong Hong
	Student ID: 20241234
	Affiliation: Sogang University Computer Science and Engineering 
	Interests: Embedded Systems and Operating Systems
	Hobbies: Soccer, Movies*/
	xil_printf("Name: Han Yuseung \nStudent ID: 20211607 \nAffiliation: Sogang University Computer Science and Engineering \nInterests: Embedded Systems, Operating Systems and LG \n Hobbies: Music, Game\n");

	// ... And need some function to call nvme... set_auto_nvme_release? no...
}


static void complete_nvme_kv_error(unsigned int cmdSlotTag, unsigned int statusCodeType, unsigned int statusCode)
{
	NVME_COMPLETION nvmeCPL;

	nvmeCPL.dword[0] = 0;
	nvmeCPL.statusField.SCT = statusCodeType;
	nvmeCPL.statusField.SC = statusCode;
	nvmeCPL.specific = 0;
	set_auto_nvme_cpl(cmdSlotTag, nvmeCPL.specific, nvmeCPL.statusFieldWord);
}

void handle_nvme_kv_put(unsigned int cmdSlotTag, NVME_IO_COMMAND *nvmeIOCmd)
{
	unsigned int key, startLba, nlb, valueLength, kvStatus;

	key = nvmeIOCmd->dword[10];
	nlb = nvmeIOCmd->dword[12];
	valueLength = nvmeIOCmd->dword[13];

	if(nlb >= MAX_NUM_OF_NLB)
	{
		complete_nvme_kv_error(cmdSlotTag, SCT_GENERIC_COMMAND_STATUS, SC_INVALID_FIELD_IN_COMMAND);
		return;
	}

	kvStatus = KvFtlPut(key, nlb, valueLength, &startLba);
	if(kvStatus == KV_FTL_INVALID_VALUE)
	{
		complete_nvme_kv_error(cmdSlotTag, SCT_GENERIC_COMMAND_STATUS, SC_INVALID_FIELD_IN_COMMAND);
		return;
	}
	else if(kvStatus != KV_FTL_SUCCESS)
	{
		complete_nvme_kv_error(cmdSlotTag, SCT_GENERIC_COMMAND_STATUS, SC_CAPACITY_EXCEEDED);
		return;
	}

	ReqTransNvmeToSlice(cmdSlotTag, startLba, nlb, IO_NVM_WRITE);
}

void handle_nvme_kv_get(unsigned int cmdSlotTag, NVME_IO_COMMAND *nvmeIOCmd)
{
	unsigned int key, startLba, valueLength, readNlb;

	key = nvmeIOCmd->dword[10];
	if(nvmeIOCmd->dword[12] >= MAX_NUM_OF_NLB)
	{
		complete_nvme_kv_error(cmdSlotTag, SCT_GENERIC_COMMAND_STATUS, SC_INVALID_FIELD_IN_COMMAND);
		return;
	}

	if(!FindKvIndexEntry(key, &startLba, &valueLength))
	{
		complete_nvme_kv_error(cmdSlotTag, SCT_VENDOR_SPECIFIC, SC_KV_KEY_NOT_EXIST);
		return;
	}

	if(valueLength == 0)
	{
		complete_nvme_kv_error(cmdSlotTag, SCT_GENERIC_COMMAND_STATUS, SC_INTERNAL_DEVICE_ERROR);
		return;
	}

	readNlb = KvFtlBlockCountFromLength(valueLength) - 1;
	if(readNlb > nvmeIOCmd->dword[12])
	{
		complete_nvme_kv_error(cmdSlotTag, SCT_GENERIC_COMMAND_STATUS, SC_INVALID_FIELD_IN_COMMAND);
		return;
	}

	ReqTransKvGetToSlice(cmdSlotTag, startLba, readNlb, valueLength);
}



void handle_nvme_io_cmd(NVME_COMMAND *nvmeCmd)
{
	NVME_IO_COMMAND *nvmeIOCmd;
	NVME_COMPLETION nvmeCPL;
	unsigned int opc;
	nvmeIOCmd = (NVME_IO_COMMAND*)nvmeCmd->cmdDword;
	/*		xil_printf("OPC = 0x%X\r\n", nvmeIOCmd->OPC);
			xil_printf("PRP1[63:32] = 0x%X, PRP1[31:0] = 0x%X\r\n", nvmeIOCmd->PRP1[1], nvmeIOCmd->PRP1[0]);
			xil_printf("PRP2[63:32] = 0x%X, PRP2[31:0] = 0x%X\r\n", nvmeIOCmd->PRP2[1], nvmeIOCmd->PRP2[0]);
			xil_printf("dword10 = 0x%X\r\n", nvmeIOCmd->dword10);
			xil_printf("dword11 = 0x%X\r\n", nvmeIOCmd->dword11);
			xil_printf("dword12 = 0x%X\r\n", nvmeIOCmd->dword12);*/


	opc = (unsigned int)nvmeIOCmd->OPC;

	switch(opc)
	{
		case IO_NVM_FLUSH:
		{
		//	xil_printf("IO Flush Command\r\n");
			nvmeCPL.dword[0] = 0;
			nvmeCPL.specific = 0x0;
			set_auto_nvme_cpl(nvmeCmd->cmdSlotTag, nvmeCPL.specific, nvmeCPL.statusFieldWord);
			break;
		}
		case IO_NVM_WRITE:
		{
			//xil_printf("IO Write Command\r\n");
			handle_nvme_io_write(nvmeCmd->cmdSlotTag, nvmeIOCmd);
			break;
		}
		case IO_NVM_READ:
		{
//			xil_printf("IO Read Command\r\n");
			handle_nvme_io_read(nvmeCmd->cmdSlotTag, nvmeIOCmd);
			break;
		}
		case IO_NVM_HELLO:
		{
			xil_printf("IO Hello Command\r\n");
			handle_nvme_io_hello();

			nvmeCPL.dword[0] = 0;
			nvmeCPL.specific = 0x0;
			set_auto_nvme_cpl(nvmeCmd->cmdSlotTag, nvmeCPL.specific, nvmeCPL.statusFieldWord);
			break;
		}
		// Task3
			case IO_NVM_KV_GET:
			{
				handle_nvme_kv_get(nvmeCmd->cmdSlotTag, nvmeIOCmd);
				break;
			}
			case IO_NVM_KV_PUT:
			{
				handle_nvme_kv_put(nvmeCmd->cmdSlotTag, nvmeIOCmd);
				break;
			}

		default:
		{
			xil_printf("Not Support IO Command OPC: %X\r\n", opc);
			ASSERT(0);
			break;
		}
	}
}
